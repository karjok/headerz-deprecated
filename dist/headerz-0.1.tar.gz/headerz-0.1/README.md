# headerz
A simple header string parser
