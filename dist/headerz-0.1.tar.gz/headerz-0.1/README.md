# headerz
A simple header string parser from HttpCanary (Android App)


<b>Instalation</b></br>
<pre>pip install headerz</pre></br>

<b>Usage</b></br>
<pre>
import headerz
</pre>
